<?php
	/*
	 * Langue: francaise
	 * D�fini comme le fichier de langue par d�faut
	 */
	$intitule = 'Stage &agrave; Quadran';
	$stage = 'Stage &agrave; Quadran';
	$presentation = '
			<p>
				Le stage que j\'ai effectu&eacute; dans la soci&eacute;t&eacute; quandran est confidentiel.
				Il m\'a permis de manipuler:
					<ul> 
					<li> le premier outils de cr&eacute;ation d\'IHM Java "Swing" </li> 
					<li> le format json  </li> 
					<li> une servlet pour r&eacute;cupeacute;rer dynamiquement des donn&eacute;es au sein d\'un serveur HTTP.</li> 
					<li> les criteres de qualit&eacute; pour un site web</li> 
					<li> et un serveur tomcat. </li> 
				</ul>  
				Nous avons utiliseacute; la m&eacute;thode de gestion de projet Agile pour avoir un produit utilisable quel qu\'en soit l\'avancement.
				Ce stage m\'a &eacute;galement permis d\'etre confront&eacute; au milieu de l\'entreprise.
			</p>

			<p>
				References :
			</p>

			<ul> 
					<li> QUADRAN  <a href="http://www.quadran.eu/" class="link">website</a></li> 
			</ul> 
			';
	 
?>