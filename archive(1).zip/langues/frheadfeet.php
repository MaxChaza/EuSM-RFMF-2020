<?php
	/*
	 * Langue: francaise
	 * D�fini comme le fichier de langue par d�faut
	 */
	$projets = 'Projets';
	$projetut = 'Projet Tuteur&eacute;';
	$autres = 'Autres'; 
?>