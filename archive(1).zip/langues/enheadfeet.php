<?php
	/*
	 * Langue: anglais
	 */ 
	$projets = 'Projects';
	$projetut = 'Tutering Project';
	$autres = 'Others';
?>