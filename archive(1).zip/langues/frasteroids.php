<?php

	/*

	 * Langue: francaise

	 * D�fini comme le fichier de langue par d�faut

	 */

	$intitule = 'Asteroids';

	$presentation = '

		<p>

				Pour ma 3&egrave;me ann&eacute;e de license informatique, j\'ai d&ucirc; cr&eacute;er un jeu. J\'ai choisis de d&eacute;velopper le jeu "Asteroids".

				Asteroids est un jeu vid&eacute;o r&eacute;alis&eacute; en Novembre 1979 par Atari Inc.

			</p>

			<p>

				Le joueur dirige un vaiseau spacial dans un champ d\'ast&eacute;ro&iuml;des qui est travers&eacute; p&eacute;riodiquement par des soucoupes volantes. Le but du jeu est de d&eacute;truire des ast&eacute;ro&iuml;des sans entrer en collisions avec ces derniers, ou &ecirc;tre tu&eacute; par les martiens.

			</p>

				Pour d&eacute;velopper ce jeu j\'ai utilis&eacute; le lagage Java. Il est compos&eacute; du plateau de jeu, d\'un menu des meilleurs scores (qui n\'est pas dans l\'applet d\'en dessous) et d\'un menu d\'aide.

			<p>

		

			</p>

			';

	$telecharge = 'T&eacute;l&eacute;charger le jeu complet.';

?>