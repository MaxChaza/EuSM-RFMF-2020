<?php
	/*
	 * Langue: anglais
	 */ 
	$intitule = 'Internship from Quadran';
	$stage = 'Internship from Quadran';
	$presentation = '
			<p>
				My Internship from Quadran is confidential.
				It allowed to me to treat:
				<ul> 
					<li> the first 
					le premier tool to create Java GUI "Swing" </li> 
					<li> the json template</li> 
					<li> a servlet to get back dynamically datas on an HTTP. server</li> 
					<li> the web site quality requirements</li> 
					<li> and a tomcat JavaServer. </li> 
				</ul>  
				We used the Agile progect management to have an usable product whatever the progress.
				This internship allowed me to be faced of the environment of the company.
			</p>

			<p>
				References :
			</p>

			<ul> 
					<li> QUADRAN  <a href="http://www.quadran.eu/" class="link">web site</a></li> 
			</ul> 
			';
	 
?>