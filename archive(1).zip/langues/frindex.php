<?php

	/*

	 * Langue: francaise

	 * D�fini comme le fichier de langue par d�faut

	 */

	$intitule = 'D&eacute;veloppeur Informatique';

	$stage = 'Stage &agrave; Quadran';

	$presentation = '

	<p>

				Bienvenue sur mon site personnel!

	</p>

	<p>

				Je suis un &eacute;tudiant dipl&ocirc;m&eacute; en licence 3 informatique, &agrave; l\'Universit&eacute; de Limoges.

				Mes int&eacute;r&ecirc;ts tournent autour du d&eacute;veloppement logiciel ainsi que du d&eacute;veloppement web. Je suis notamment d&eacute;veloppeur Java &agrave; mes heures perdues. 

	</p>

				Je pr&eacute;sente d&eacute;sormais mes projets, exp&eacute;riences, recherches que j\'ai effectu&eacute; pour mes besoins personnels, ou en tant que projets effectu&eacute;s durant mon cursus universitaire. 	

	';

	 

?>