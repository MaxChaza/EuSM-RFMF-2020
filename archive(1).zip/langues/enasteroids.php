<?php

	/*

	 * Langue: anglais

	 */

	$intitule = 'Asteroids';

	$stage = 'Internship from Quadran';

	$presentation = '

		<p>

				During my third year of university of computing sciences, I most create a game. I chose to develop the game "Asteroids".

				Asteroids is a video arcade game released in November 1979 by Atari Inc.

			</p>

			<p>

				The player controls a spaceship in an asteroid field which is periodically traversed by flying saucers. The object of the game is to shoot and destroy asteroids and saucers while not colliding with either, or being hit by the saucers\' counter-fire.

			</p>

			<p>

				To develop this game I used Java language. It\'s composed to the game, a main to the highscore (not include in the applet on the bottom) and an help main.  

			</p>


			';

	$telecharge = 'Download the complete game.';

?>