<?php
	/*
	 * Langue: francaise
	 * D�fini comme le fichier de langue par d�faut
	 */
	$presentation = '
			<table id="page-table">
				<tr>
					<td id="page-td">
						<p>
							
							Ci-dessous vous pouvez me contacter par mail : <A HREF="mailto:maxime.chazalviel@gmail.com">maxime.chazalviel@gmail.com</A>. 
							
						</p>
						<p>
							<p>
							Vous pouvez &eacute;galement me joindre sur se formulaire :
			';
	$presentation2 = '
										<a style="font:8px Arial;color:#5C5C5C;" href="http://fr.foxyform.com">Formulaire de contact</a>
									</td>
								</tr>
							</table>
							</p>
						</p>
					</td>
				</tr>
			</table>
			';
	 
?>