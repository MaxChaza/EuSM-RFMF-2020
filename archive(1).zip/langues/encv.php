<?php
	/*
	 * Langue: anglais
	 */ 
	$projets = 'Projects';
	$projetut = 'Tutering Project';
	$autres = 'Others';
	$stage = 'Internship from Quadran';
	$presentation = '
			<p>
							Below you can consult my professional CV. You can also download it in PDF format.
			</p>
			';
	$telecharger = 'Download the CV.';
	 
?>