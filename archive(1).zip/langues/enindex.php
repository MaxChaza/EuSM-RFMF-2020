<?php
	/*
	 * Langue: anglais
	 */
	$intitule = 'IT developer';  
	$stage = 'Internship from Quadran';
	$presentation = '
	<p>
				Welcome in my website!
	</p>
	<p>
				I\'m graduate in 3rd year of university of computing sciences, at the University of Limoges.

				My interests turn around the software development as well as web development. I am in particular developer Java at my lost hours.
	</p>
				Now I present my projects, experiments, research which I carried for my personal needs, or for projects carried during my university course.
				';
	 
?>