<?php
	/*
	 * Langue: francaise
	 * D�fini comme le fichier de langue par d�faut
	 */
	$presentation = '
			<p>
							Ci-dessous vous pouvez consulter mon CV professionnel. Vous pouvez &eacute;galement le t&eacute;l&eacute;charger au format PDF.
			</p>
			';
	$telecharger = 'T&eacute;l&eacute;charger le CV.';
?>