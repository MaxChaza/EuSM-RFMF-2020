<?php
	/*
	 * Langue: anglais
	 */ 
	$presentation = '
			<table id="page-table">
				<tr>
					<td id="page-td">
						<p>
							
							Below, you can contact me by mail : <A HREF="mailto:maxime.chazalviel@gmail.com">maxime.chazalviel@gmail.com</A>. 
							
						</p>
						<p>
							<p>
							You can also join to me with this form :
			';
	$presentation2 = '
			
										<a style="font:8px Arial;color:#5C5C5C;" href="http://fr.foxyform.com">Form of contact</a>
									</td>
								</tr>
							</table>
							</p>
						</p>
					</td>
				</tr>
			</table>
			';
	 
?>