<div id="lignePied">
		</div>
		
		<div id="piedPage">
			<div id="gauche">
				<li><a href="../index.php">Index</a></li>
				<li><a href="./cv.php">CV</a></li>
				<li><a href="./contact.php">Contact</a></li>
				<!-- <li><a href="#"><?php echo $autres;?></a></li>-->
		</div>
		
		<div id="lang">
				<?php
					echo '<li><a  href="./'.$page.'.php?lang=fr" target="_top"><img src="../images/fr.png" alt="Fran&ccedil;ais" style="border:none"></a></li>';
					echo '<li><a  href="./'.$page.'.php?lang=en" target="_top"><img src="../images/en.png" alt="Anglais" style="border:none"></a></li>';
				?>
			</div>
		</div>
	</div>
</body>
</html>
