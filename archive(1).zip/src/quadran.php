<?php
	$page = 'quadran';
	$dir_lang = '../langues/';
	include('../langues.php');
	
	include('./headerProjet.php');
?>
	<div id="divpresentation" >
		<?php echo $presentation;?>
	</div>
	
	<div id ="espace">
	</div>	
	
<?php
		include('./piedProjet.php');
?>				
		